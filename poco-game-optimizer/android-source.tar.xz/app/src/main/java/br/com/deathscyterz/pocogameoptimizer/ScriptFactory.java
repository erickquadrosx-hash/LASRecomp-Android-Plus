package br.com.deathscyterz.pocogameoptimizer;

public final class ScriptFactory {
    private ScriptFactory() {}

    public static String commands(String packageName, Profile profile) {
        if (!packageName.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) {
            return "Pacote inválido";
        }
        String base = "adb shell cmd game list-modes " + packageName + "\n";
        if (profile == Profile.EXPERIMENTAL) {
            return base + "adb shell device_config get game_overlay " + packageName +
                    "\n# BACKUP primeiro: use o .ps1 exportado (salva e restaura configurações)." +
                    "\nadb shell device_config put game_overlay " + packageName +
                    " \"mode=2,downscaleFactor=0.9,fps=60\"" +
                    "\nadb shell cmd game mode performance " + packageName;
        }
        return base + "adb shell cmd game mode " + profile.androidMode + " " + packageName;
    }

    public static String powershell(String pkg, Profile profile) {
        if (!pkg.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) throw new IllegalArgumentException("pacote inválido");
        String text = """
                # POCO Game Optimizer | PowerShell para Windows - segurança e reversão
                # Execute com o POCO X7 Pro conectado e Depuração USB autorizada.
                param([ValidateSet('stable','performance','battery','experimental','restore')]
                      [string]$Perfil = '__PROFILE__',
                      [string]$Pacote = '__PACKAGE__')
                $ErrorActionPreference = 'Stop'
                if ($Pacote -notmatch '^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$') { throw 'Pacote inválido.' }
                $adbCmd = Get-Command adb -ErrorAction SilentlyContinue
                if ($adbCmd) { $adb = $adbCmd.Source }
                else {
                  $locais = @(
                    "$env:LOCALAPPDATA\\Android\\Sdk\\platform-tools\\adb.exe",
                    "$PSScriptRoot\\platform-tools\\adb.exe",
                    "$PSScriptRoot\\adb.exe"
                  )
                  $adb = $locais | Where-Object { Test-Path $_ } | Select-Object -First 1
                }
                if (-not $adb) { throw 'ADB não encontrado. Instale o Android SDK Platform-Tools ou coloque adb.exe no PATH.' }
                & $adb start-server | Out-Null
                $devices = (& $adb devices) -join "`n"
                if ($devices -notmatch '(?m)^\\S+\\s+device$') {
                    throw 'Nenhum aparelho autorizado. Conecte o USB e confirme Depuração USB no telefone.'
                }
                $saveFile = Join-Path $PSScriptRoot ("backup_" + $Pacote + ".json")
                function Exec-ADB([string[]]$Arguments) {
                    $saida = (& $adb @Arguments 2>&1) -join "`n"
                    if ($LASTEXITCODE -ne 0 -or $saida -match '(?im)^(Error:|Exception|Security exception|Unknown command)') {
                        throw "Comando ADB falhou: $saida"
                    }
                    return $saida
                }
                if ($Perfil -eq 'restore') {
                    if (-not (Test-Path $saveFile)) { throw 'Nenhum backup anterior para esse pacote.' }
                    $old = Get-Content -Raw -Encoding UTF8 $saveFile | ConvertFrom-Json
                    if ($old.overlay -eq 'null' -or [string]::IsNullOrWhiteSpace($old.overlay)) {
                        Exec-ADB @('shell','device_config','delete','game_overlay',$Pacote) | Out-Null
                    } else {
                        Exec-ADB @('shell','device_config','put','game_overlay',$Pacote,[string]$old.overlay) | Out-Null
                    }
                    if ($old.mode -match '^(standard|performance|battery|custom)$') {
                        Exec-ADB @('shell','cmd','game','mode',[string]$old.mode,$Pacote) | Out-Null
                    }
                    Write-Host 'Configurações anteriores restauradas (quando suportadas).' -ForegroundColor Green
                    exit 0
                }
                $info = Exec-ADB @('shell','cmd','game','list-modes',$Pacote)
                Write-Host $info
                if ($info -match 'not of game type|not found') { throw 'Este app não foi reconhecido como jogo pelo Android.' }
                if (-not (Test-Path $saveFile)) {
                    $originalOverlay = (Exec-ADB @('shell','device_config','get','game_overlay',$Pacote)).Trim()
                    $originalMode = ''
                    if ($info -match 'current mode:\\s*(standard|performance|battery|custom)') { $originalMode = $Matches[1] }
                    @{ overlay=$originalOverlay; mode=$originalMode; package=$Pacote; created=(Get-Date).ToString('s') } |
                        ConvertTo-Json | Set-Content -Encoding UTF8 $saveFile
                    Write-Host "Backup preservado em $saveFile"
                }
                if ($Perfil -ne 'experimental' -and (Test-Path $saveFile)) {
                    $baseline = Get-Content -Raw -Encoding UTF8 $saveFile | ConvertFrom-Json
                    if ($baseline.overlay -eq 'null' -or [string]::IsNullOrWhiteSpace($baseline.overlay)) {
                        Exec-ADB @('shell','device_config','delete','game_overlay',$Pacote) | Out-Null
                    } else {
                        Exec-ADB @('shell','device_config','put','game_overlay',$Pacote,[string]$baseline.overlay) | Out-Null
                    }
                    Write-Host 'Overlay original restaurado para perfil não experimental.'
                }
                if ($Perfil -eq 'experimental') {
                    Write-Warning 'Experimental: substitui intervenções do fabricante. Teste grama, árvores e transições.'
                    $confirm = Read-Host 'Confirma modo experimental? [S/N]'
                    if ($confirm -notmatch '^[sS]$') { Write-Host 'Cancelado sem alterações'; exit 0 }
                    Exec-ADB @('shell','device_config','put','game_overlay',$Pacote,'mode=2,downscaleFactor=0.9,fps=60') | Out-Null
                    $modo = 'performance'
                } else { $modo = if ($Perfil -eq 'stable') { 'standard' } else { $Perfil } }
                $result = Exec-ADB @('shell','cmd','game','mode',$modo,$Pacote)
                Write-Host $result
                if ($result -match '(?i)not supported|not available|not of game type') { Write-Warning 'Modo não suportado nesse jogo/HyperOS.' }
                Write-Host 'Perfil enviado. Feche e reabra o jogo. Não há garantia de aumento de FPS.' -ForegroundColor Cyan
                Write-Host "Para restaurar: .\\$(Split-Path -Leaf $PSCommandPath) -Perfil restore -Pacote $Pacote"
                """;
        return text.replace("__PACKAGE__",pkg).replace("__PROFILE__",profile.key);
    }
}

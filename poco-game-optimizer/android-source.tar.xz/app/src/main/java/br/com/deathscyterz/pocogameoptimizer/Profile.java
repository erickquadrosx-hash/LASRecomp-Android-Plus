package br.com.deathscyterz.pocogameoptimizer;

public enum Profile {
    STABLE("stable", "ESTÁVEL", "Aprovado", "Mantém 60 FPS de referência, resolução 1×, bilinear, AA e quadros gerados desligados. Não altera renderização de outros APKs.", "standard"),
    PERFORMANCE("performance", "DESEMPENHO", "Seguro", "Solicita Modo Jogo: desempenho ao Android, quando suportado pelo jogo e HyperOS.", "performance"),
    BATTERY("battery", "ECONOMIA", "30 FPS sugeridos", "Solicita Modo Jogo: economia. Limite de FPS só existe quando o sistema/jogo der suporte.", "battery"),
    EXPERIMENTAL("experimental", "EXPERIMENTAL", "0,90× • backup", "Via ADB, tenta resolução interna 90% e teto de 60 FPS. Pode não funcionar. Faça testes visuais.", "performance");

    public final String key, label, tag, description, androidMode;
    Profile(String key, String label, String tag, String description, String androidMode) {
        this.key=key; this.label=label; this.tag=tag;
        this.description=description; this.androidMode=androidMode;
    }
    public static Profile from(String key) {
        for (Profile profile : values()) if (profile.key.equals(key)) return profile;
        return STABLE;
    }
}

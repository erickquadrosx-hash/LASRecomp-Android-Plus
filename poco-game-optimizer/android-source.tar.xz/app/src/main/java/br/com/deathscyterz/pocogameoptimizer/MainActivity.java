package br.com.deathscyterz.pocogameoptimizer;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11,17,30);
    private static final int SURFACE = Color.rgb(21,30,47);
    private static final int SURFACE2 = Color.rgb(28,41,62);
    private static final int ACCENT = Color.rgb(103,232,249);
    private static final int WHITE = Color.rgb(242,248,255);
    private static final int MUTED = Color.rgb(153,173,195);
    private static final int LINE = Color.rgb(46,61,84);
    private static final int EXPORT_CODE = 4102;

    private SharedPreferences prefs;
    private final List<Game> games = new ArrayList<>();
    private LinearLayout gameContainer, profileGrid, selectedInfo, diagnostics;
    private TextView gameCount, profileDescription, titleSelected, subtitleSelected, selectionHint;
    private String filter = "", selectedPackage = null, pendingScript = null;
    private Profile profile = Profile.STABLE;
    private boolean showSystem = false;
    private boolean scanned = false;

    static class Game {
        final String pkg, label;
        final ResolveInfo launchInfo;
        final boolean isGame, isSystem;
        Game(String pkg, String label, ResolveInfo launchInfo, boolean isGame, boolean isSystem) {
            this.pkg = pkg; this.label = label; this.launchInfo = launchInfo;
            this.isGame = isGame; this.isSystem = isSystem;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("poco_game_profiles", MODE_PRIVATE);
        selectedPackage = prefs.getString("last_game", null);
        if (selectedPackage != null) profile = Profile.from(prefs.getString("profile::" + selectedPackage, "stable"));
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
        loadGames();
    }

    @Override public void onResume() {
        super.onResume();
        if (diagnostics != null) fillDiagnostics();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable background(int color, int border, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radius));
        if (border != 0) gd.setStroke(dp(1), border);
        return gd;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width == -1 ? -1 : dp(width), height == -2 ? -2 : dp(height));
    }

    private void space(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, lp(-1, height));
    }

    private LinearLayout card() {
        LinearLayout c = column();
        c.setPadding(dp(17), dp(17), dp(17), dp(17));
        c.setBackground(background(SURFACE, LINE, 21));
        return c;
    }

    private TextView button(String label, boolean primary, View.OnClickListener action) {
        TextView b = text(label, 13, primary ? BG : WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12),dp(12),dp(12),dp(12));
        b.setBackground(background(primary ? ACCENT : SURFACE2, primary ? 0 : LINE, 13));
        b.setOnClickListener(action);
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private void sectionTitle(LinearLayout root, String title, String sub) {
        root.addView(text(title, 18, WHITE,true));
        if (sub != null) { space(root, 3); root.addView(text(sub,12,MUTED,false)); }
        space(root, 12);
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(25), dp(18), dp(42));
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(dp(18), dp(25) + bars.top, dp(18), dp(42) + bars.bottom);
                return insets;
            });
        }
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout brand = row();
        TextView mark = text("✦", 25, BG,true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(background(ACCENT,0,13));
        brand.addView(mark, lp(50,50));
        LinearLayout logo = column();
        logo.addView(text("POCO GAME",20, WHITE,true));
        logo.addView(text("GRAPHICS OPTIMIZER  ·  v1.0",10, ACCENT,true));
        LinearLayout.LayoutParams brandTextParams = lp(-1,-2);
        brandTextParams.leftMargin = dp(12);
        brand.addView(logo,brandTextParams);
        root.addView(brand);
        space(root,17);

        LinearLayout hardware = card();
        hardware.setBackground(background(Color.rgb(17,37,55),Color.rgb(32,94,119),20));
        TextView tag = text("PERFIL DO DISPOSITIVO",11,ACCENT,true);
        hardware.addView(tag);
        space(hardware,6);
        hardware.addView(text("Dimensity 8400-Ultra",22,WHITE,true));
        hardware.addView(text("GPU Mali-G720  •  otimizado para POCO X7 Pro",13,MUTED,false));
        hardware.addView(text("Detectado: " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE,11,MUTED,false));
        space(hardware,12);
        diagnostics = row();
        hardware.addView(diagnostics);
        fillDiagnostics();
        root.addView(hardware);
        space(root,22);

        sectionTitle(root,"Perfis gráficos", "A referência estável é preservada; testes separados não substituem o perfil aprovado.");
        profileGrid = column();
        root.addView(profileGrid);
        space(root,12);
        LinearLayout detail = card();
        profileDescription = text("",13,WHITE,false);
        detail.addView(profileDescription);
        space(detail,9);
        detail.addView(text("As opções de renderização devem ser ajustadas no menu do próprio jogo. Alterações globais precisam de suporte do Android ou ADB.",11,MUTED,false));
        root.addView(detail);
        repaintProfiles();
        space(root,24);

        sectionTitle(root,"Escolher jogo", "Mostra APKs com ícone de inicialização instalados no aparelho.");
        LinearLayout searchCard = card();
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(WHITE);
        search.setHintTextColor(MUTED);
        search.setTextSize(14);
        search.setHint("Buscar jogo ou pacote...");
        search.setPadding(dp(10),dp(8),dp(10),dp(8));
        search.setBackground(background(BG,LINE,12));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter = s.toString().trim().toLowerCase(Locale.ROOT); redrawGames();
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        searchCard.addView(search,lp(-1,-2));
        space(searchCard,12);
        LinearLayout controls = row();
        gameCount = text("Carregando aplicativos...",11,MUTED,false);
        controls.addView(gameCount,new LinearLayout.LayoutParams(0,-2,1));
        TextView toggle = button("Mostrar sistema",false,v -> {
            showSystem = !showSystem;
            ((TextView)v).setText(showSystem ? "Ocultar sistema" : "Mostrar sistema");
            redrawGames();
        });
        controls.addView(toggle);
        searchCard.addView(controls);
        space(searchCard,12);
        gameContainer = column();
        searchCard.addView(gameContainer);
        root.addView(searchCard);
        space(root,20);

        sectionTitle(root,"Jogo selecionado",null);
        selectedInfo = card();
        titleSelected = text("Selecione um jogo acima",16,WHITE,true);
        subtitleSelected = text("O perfil será salvo exclusivamente para esse jogo.",12,MUTED,false);
        selectedInfo.addView(titleSelected);
        selectedInfo.addView(subtitleSelected);
        space(selectedInfo,12);
        selectionHint = text("Nenhum jogo selecionado",12,ACCENT,false);
        selectedInfo.addView(selectionHint);
        space(selectedInfo,12);
        selectedInfo.addView(button("SALVAR PERFIL DO JOGO",true,v -> saveProfile()), lp(-1,-2));
        space(selectedInfo,9);
        LinearLayout actRow = row();
        TextView launch = button("ABRIR JOGO",false,v -> launchGame());
        TextView copy = button("COPIAR ADB",false,v -> copyCommands());
        actRow.addView(launch,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-2,1); cp.leftMargin=dp(8);
        actRow.addView(copy,cp);
        selectedInfo.addView(actRow);
        space(selectedInfo,9);
        selectedInfo.addView(button("EXPORTAR SCRIPT POWERSHELL COM BACKUP",false,v -> exportScript()),lp(-1,-2));
        space(selectedInfo,9);
        selectedInfo.addView(button("CONFIGURAÇÕES DO APLICATIVO",false,v -> appSettings()),lp(-1,-2));
        root.addView(selectedInfo);
        updateSelection();
        space(root,20);

        sectionTitle(root,"Ajuste interno aprovado", "Referência dos testes anteriores; configurar dentro do APK compatível.");
        LinearLayout approved = card();
        String[][] specs = {
                {"FPS nativos", "60 (usar 30 se instável)"},
                {"Resolução", "1,0×"},
                {"Escalonamento", "Bilinear"},
                {"Geração de quadros", "Desligada"},
                {"Anti-aliasing", "Desligado"},
                {"Driver", "Sistema / Mali"},
                {"Precisão de cálculo", "FP16 nativo se suportado"},
                {"Proporção / Tela cheia", "16:9 / desativada"},
                {"Energia", "Equilibrado"}
        };
        for (int i=0; i<specs.length; i++) {
            LinearLayout one = row();
            TextView left = text(specs[i][0],12,MUTED,false);
            TextView right = text(specs[i][1],12,WHITE,true);
            right.setGravity(Gravity.END);
            one.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            one.addView(right,new LinearLayout.LayoutParams(0,-2,1));
            approved.addView(one);
            if (i != specs.length-1) space(approved,11);
        }
        root.addView(approved);
        space(root,20);

        sectionTitle(root,"Ajustes de sistema",null);
        LinearLayout system = card();
        system.addView(button("ABRIR TELA E TAXA DE ATUALIZAÇÃO",false,v -> openSettings(Settings.ACTION_DISPLAY_SETTINGS)),lp(-1,-2));
        space(system,9);
        system.addView(button("ABRIR ECONOMIA DE BATERIA",false,v -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)),lp(-1,-2));
        space(system,12);
        system.addView(text("No Game Turbo do HyperOS, priorize estabilidade. O app não força drivers, clocks, shaders ou FPS de outro processo e não usa root.",12,MUTED,false));
        root.addView(system);
        space(root,15);
        root.addView(text("Privacidade: sem Internet, sem anúncios, sem serviços em segundo plano. As informações de perfil ficam somente neste dispositivo.",11,MUTED,false));
    }

    private void fillDiagnostics() {
        diagnostics.removeAllViews();
        float refresh = getWindowManager().getDefaultDisplay().getRefreshRate();
        Intent bat = registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        String temp = "—";
        String power = "—";
        if (bat != null) {
            int raw=bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1);
            if (raw>0) temp=String.format(Locale.forLanguageTag("pt-BR"),"%.1f°C",raw/10f);
            int level=bat.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            if (level>=0) power=level+"%";
        }
        String[][] vals={{"TELA",String.format(Locale.ROOT,"%.0f Hz",refresh)}, {"BATERIA",power}, {"TEMP. BATERIA",temp}};
        for (int i=0;i<vals.length;i++) {
            LinearLayout p=column();
            p.addView(text(vals[i][0],9,MUTED,true));
            space(p,3); p.addView(text(vals[i][1],14,WHITE,true));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0,-2,1);
            if (i>0) pp.leftMargin=dp(6);
            diagnostics.addView(p,pp);
        }
        // Não inferimos frequência da GPU a partir do Hz da tela.
    }

    private void repaintProfiles() {
        if (profileGrid == null) return;
        profileGrid.removeAllViews();
        Profile[] array = Profile.values();
        for (int i=0;i<array.length;i+=2) {
            LinearLayout r=row();
            for (int j=i;j<Math.min(i+2,array.length);j++) {
                final Profile p=array[j];
                boolean active = profile == p;
                LinearLayout tile = column();
                tile.setPadding(dp(13),dp(15),dp(12),dp(14));
                tile.setBackground(background(active ? Color.rgb(21,51,71) : SURFACE,active ? ACCENT : LINE,17));
                tile.addView(text(p.label,13,active ? ACCENT:WHITE,true));
                space(tile,4);
                tile.addView(text(p.tag,11,active ? WHITE:MUTED,false));
                tile.setOnClickListener(v -> { profile=p; repaintProfiles(); updateSelection(); });
                LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(78),1);
                if (j%2==1) pp.leftMargin=dp(10);
                r.addView(tile,pp);
            }
            profileGrid.addView(r);
            space(profileGrid,10);
        }
        profileDescription.setText(profile.description);
    }

    private void loadGames() {
        new Thread(() -> {
            List<Game> found = new ArrayList<>();
            PackageManager pm = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN,null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> activities = pm.queryIntentActivities(intent,0);
            for (ResolveInfo ri: activities) {
                if (ri.activityInfo == null || ri.activityInfo.applicationInfo == null) continue;
                ApplicationInfo ai=ri.activityInfo.applicationInfo;
                if (getPackageName().equals(ai.packageName)) continue;
                boolean system=(ai.flags & ApplicationInfo.FLAG_SYSTEM)!=0;
                boolean game=ai.category==ApplicationInfo.CATEGORY_GAME;
                String label=String.valueOf(ri.loadLabel(pm));
                if (label.trim().isEmpty()) label=ai.packageName;
                boolean duplicate=false;
                for (Game g:found) if (g.pkg.equals(ai.packageName)) { duplicate=true; break; }
                if (!duplicate) found.add(new Game(ai.packageName,label,ri,game,system));
            }
            Collections.sort(found,Comparator.comparing((Game g) -> !g.isGame).thenComparing(g -> g.label.toLowerCase(Locale.ROOT)));
            runOnUiThread(() -> {
                games.clear(); games.addAll(found); scanned=true;
                redrawGames(); updateSelection();
            });
        }, "installed-games-scan").start();
    }

    private void redrawGames() {
        if (gameContainer == null || gameCount==null) return;
        gameContainer.removeAllViews();
        int count=0;
        for (Game game:games) {
            if (!showSystem && game.isSystem) continue;
            if (!filter.isEmpty() && !game.label.toLowerCase(Locale.ROOT).contains(filter) && !game.pkg.toLowerCase(Locale.ROOT).contains(filter)) continue;
            count++;
            // Mostra no máximo 90 itens de uma vez para evitar rolagem excessiva.
            if (count>90) continue;
            boolean active=game.pkg.equals(selectedPackage);
            LinearLayout r = row();
            r.setPadding(dp(9),dp(10),dp(9),dp(10));
            r.setBackground(background(active ? Color.rgb(21,51,71) : BG,active?ACCENT:0,12));
            ImageView icon=new ImageView(this);
            try { icon.setImageDrawable(game.launchInfo.loadIcon(getPackageManager())); }
            catch (Exception ex) { icon.setImageResource(android.R.drawable.sym_def_app_icon); }
            r.addView(icon,lp(38,38));
            LinearLayout desc=column();
            TextView name=text(game.label,13,WHITE,true);
            name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            TextView path=text(game.pkg,10,MUTED,false);
            path.setSingleLine(true); path.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            desc.addView(name); desc.addView(path);
            LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(0,-2,1); d.leftMargin=dp(12);
            r.addView(desc,d);
            r.addView(text(active ? "✓" : game.isGame ? "JOGO" : "›",11, active ? ACCENT : MUTED,true));
            r.setOnClickListener(v -> {
                selectedPackage=game.pkg;
                prefs.edit().putString("last_game",selectedPackage).apply();
                profile=Profile.from(prefs.getString("profile::"+selectedPackage,"stable"));
                repaintProfiles(); updateSelection(); redrawGames();
            });
            gameContainer.addView(r);
            space(gameContainer,7);
        }
        gameCount.setText(!scanned ? "Carregando..." : count + " apps encontrados" + (count>90?" · use busca":""));
        if (count==0 && scanned) gameContainer.addView(text("Nenhum aplicativo encontrado. Use “Mostrar sistema” ou altere sua busca.",12,MUTED,false));
    }

    private Game chosen() {
        if (selectedPackage==null) return null;
        for (Game g:games) if (g.pkg.equals(selectedPackage)) return g;
        return null;
    }

    private void updateSelection() {
        if (titleSelected == null) return;
        Game game=chosen();
        titleSelected.setText(game!=null ? game.label : "Selecione um jogo acima");
        subtitleSelected.setText(game!=null ? game.pkg : "O perfil será salvo exclusivamente para esse jogo.");
        selectionHint.setText(game!=null ? "Perfil selecionado: " + profile.label + " • ADB opcional para modo Android" : "Nenhum jogo selecionado");
    }

    private Game requireGame() {
        Game game=chosen();
        if (game==null) Toast.makeText(this,"Escolha um jogo primeiro",Toast.LENGTH_SHORT).show();
        return game;
    }

    private void saveProfile() {
        Game g=requireGame(); if (g==null) return;
        prefs.edit().putString("profile::"+g.pkg,profile.key).apply();
        Toast.makeText(this,"Perfil salvo para "+g.label,Toast.LENGTH_LONG).show();
    }

    private void copyCommands() {
        Game g=requireGame(); if (g==null) return;
        String cmd=ScriptFactory.commands(g.pkg,profile);
        ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("POCO ADB",cmd));
        Toast.makeText(this,"Comandos ADB copiados. Use no Windows com ADB.",Toast.LENGTH_LONG).show();
    }

    private void exportScript() {
        Game g=requireGame(); if (g==null) return;
        pendingScript=ScriptFactory.powershell(g.pkg,profile);
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_TITLE,"POCO_"+profile.key+"_"+g.pkg+".ps1");
        try { startActivityForResult(intent,EXPORT_CODE); }
        catch (Exception e) { Toast.makeText(this,"Não foi possível abrir o seletor de arquivos",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==EXPORT_CODE && resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingScript!=null) {
            try (OutputStream os=getContentResolver().openOutputStream(data.getData())) {
                if (os==null) throw new IllegalStateException("Sem acesso ao destino");
                // BOM para reconhecimento de UTF-8 no Windows PowerShell 5.1.
                os.write(new byte[]{(byte)0xEF, (byte)0xBB, (byte)0xBF});
                os.write(pendingScript.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"Script exportado com rotina de backup e restauração.",Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this,"Falha ao salvar: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
            pendingScript=null;
        }
    }

    private void launchGame() {
        Game g=requireGame(); if (g==null) return;
        saveProfile();
        try {
            Intent launch=getPackageManager().getLaunchIntentForPackage(g.pkg);
            if (launch==null) throw new IllegalStateException("Sem atividade inicializável");
            startActivity(launch);
        } catch (Exception e) { Toast.makeText(this,"Não foi possível abrir este jogo",Toast.LENGTH_LONG).show(); }
    }

    private void appSettings() {
        Game g=requireGame(); if (g==null) return;
        try {
            Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+g.pkg));
            startActivity(i);
        } catch(Exception ex) { Toast.makeText(this,"Ajustes indisponíveis",Toast.LENGTH_SHORT).show(); }
    }

    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch(Exception ex) { Toast.makeText(this,"Tela de ajustes indisponível",Toast.LENGTH_SHORT).show(); }
    }
}
